# EventBot
This is going to be a big and complete bot that can cover all the important airdrops in Telegram, its news and combos.
